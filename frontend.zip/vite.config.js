import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
    proxy: {
      '/api': {
        // target: 'http://localhost:5000',
        target: 'https://neverbookstore-gmhvfea8gudxhnfd.polandcentral-01.azurewebsites.net/api/',
        changeOrigin: true,
      },
    },
  },
});
